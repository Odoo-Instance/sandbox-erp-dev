import base64

from odoo import http
from odoo import fields, http, SUPERUSER_ID, _
from odoo.http import request


#
class ClosePosPopup(http.Controller):

    @http.route(['/download/pos_session/<int:session_id>'], type='http', auth="user")
    def portal_order_page(self, session_id, report_type=None, download=True, **kw):
        session_id = request.env["cc_z_reading.z_reading"].sudo().browse(session_id)
        pdf = request.env.ref('cc_z_reading.action_z_reading_report').sudo()._render_qweb_pdf([session_id.id])[0]
        pdfhttpheaders = [('Content-Type', 'application/pdf'), ('Content-Length', len(pdf))]
        # return request.make_response(pdf, headers=pdfhttpheaders)

        result = base64.b64encode(pdf)
        attachment_obj = request.env['ir.attachment']
        # create attachment
        attachment_id = attachment_obj.sudo().create(
            {'name': "Z-reading", 'store_fname': 'name.pdf', 'datas': result})
        # prepare download url
        download_url = '/web/content/' + str(attachment_id.id) + '?download=true'
        print(attachment_id)
        # download
        base_url = request.env['ir.config_parameter'].get_param('web.base.url')
        return {
            "url": str(base_url) + str(download_url)
        }

# if report_type in ('html', 'pdf', 'text'):
#     order_sudo = request.env["cc_z_reading.z_reading"].sudo().browse(session_id)
# return self._show_report(model=order_sudo, report_type=report_type,
#                          report_ref='cc_z_reading.action_z_reading_report',
#                          download=download)
